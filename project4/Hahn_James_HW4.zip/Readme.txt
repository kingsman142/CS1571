Python version: Python 3.6.2
Additional libraries: pandas, numpy, sys, os
