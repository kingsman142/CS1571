Python version: 3.6.2 32-bit
Additional libraries: sys, os, and math
Additional resources consulted: Dr. Litman's slides, our AI textbook
Additional people discussions: None
Components not working: None
