Python: Python 3.6
Libraries: sys, os
Additional consulted resources: None
List any person discussed with: Zac Yu (Discussed high level differences between forward chaining and incremental forward chaining because it wasn't clear to me initially)
